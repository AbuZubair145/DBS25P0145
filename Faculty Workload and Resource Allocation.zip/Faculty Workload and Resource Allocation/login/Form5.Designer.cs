﻿namespace login
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label2 = new Label();
            tableLayoutPanel1 = new TableLayoutPanel();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            button9 = new Button();
            button7 = new Button();
            textBox4 = new TextBox();
            label5 = new Label();
            textBox3 = new TextBox();
            label4 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            label6 = new Label();
            label1 = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            panel1 = new Panel();
            button2 = new Button();
            panel2 = new Panel();
            button1 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            panel3 = new Panel();
            button6 = new Button();
            tableLayoutPanel1.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(321, 77);
            label2.Name = "label2";
            label2.Size = new Size(98, 20);
            label2.TabIndex = 10;
            label2.Text = "Faculty Name";
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 6;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 119F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 135F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 121F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle());
            tableLayoutPanel1.Controls.Add(label10, 4, 1);
            tableLayoutPanel1.Controls.Add(label9, 3, 1);
            tableLayoutPanel1.Controls.Add(label8, 2, 1);
            tableLayoutPanel1.Controls.Add(label7, 1, 1);
            tableLayoutPanel1.Location = new Point(289, 325);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 4;
            tableLayoutPanel1.RowStyles.Add(new RowStyle());
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 25F));
            tableLayoutPanel1.Size = new Size(469, 88);
            tableLayoutPanel1.TabIndex = 21;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(351, 0);
            label10.Name = "label10";
            label10.Size = new Size(48, 20);
            label10.TabIndex = 3;
            label10.Text = "Hours";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(216, 0);
            label9.Name = "label9";
            label9.Size = new Size(70, 20);
            label9.TabIndex = 3;
            label9.Text = "Semester";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(97, 0);
            label8.Name = "label8";
            label8.Size = new Size(54, 20);
            label8.TabIndex = 3;
            label8.Text = "Course";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(3, 0);
            label7.Name = "label7";
            label7.Size = new Size(54, 20);
            label7.TabIndex = 3;
            label7.Text = "Faculty";
            // 
            // button9
            // 
            button9.BackColor = Color.Red;
            button9.ForeColor = Color.Black;
            button9.Location = new Point(536, 216);
            button9.Name = "button9";
            button9.Size = new Size(167, 29);
            button9.TabIndex = 18;
            button9.Text = "Remove Assignment";
            button9.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(128, 128, 255);
            button7.Location = new Point(321, 216);
            button7.Name = "button7";
            button7.Size = new Size(133, 29);
            button7.TabIndex = 20;
            button7.Text = "Assign Workload ";
            button7.UseVisualStyleBackColor = false;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(536, 165);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(167, 27);
            textBox4.TabIndex = 14;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(536, 142);
            label5.Name = "label5";
            label5.Size = new Size(48, 20);
            label5.TabIndex = 11;
            label5.Text = "Hours";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(318, 165);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(167, 27);
            textBox3.TabIndex = 15;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(318, 142);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 12;
            label4.Text = "Semester";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(536, 100);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(167, 27);
            textBox2.TabIndex = 16;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(536, 77);
            label3.Name = "label3";
            label3.Size = new Size(54, 20);
            label3.TabIndex = 13;
            label3.Text = "Course";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(318, 100);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(167, 27);
            textBox1.TabIndex = 17;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Elephant", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(394, 23);
            label6.Name = "label6";
            label6.Size = new Size(236, 26);
            label6.TabIndex = 8;
            label6.Text = "WorkLoad Requests";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Elephant", 11.999999F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(367, 278);
            label1.Name = "label1";
            label1.Size = new Size(274, 26);
            label1.TabIndex = 9;
            label1.Text = "Assigned Workload List";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(35, 40, 45);
            flowLayoutPanel1.Controls.Add(panel1);
            flowLayoutPanel1.Controls.Add(panel2);
            flowLayoutPanel1.Controls.Add(button3);
            flowLayoutPanel1.Controls.Add(button4);
            flowLayoutPanel1.Controls.Add(button5);
            flowLayoutPanel1.Controls.Add(panel3);
            flowLayoutPanel1.Controls.Add(button6);
            flowLayoutPanel1.Dock = DockStyle.Left;
            flowLayoutPanel1.Location = new Point(0, 0);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(206, 450);
            flowLayoutPanel1.TabIndex = 7;
            // 
            // panel1
            // 
            panel1.Controls.Add(button2);
            panel1.Location = new Point(3, 3);
            panel1.Name = "panel1";
            panel1.Size = new Size(203, 125);
            panel1.TabIndex = 0;
            // 
            // button2
            // 
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Segoe UI", 12F);
            button2.ForeColor = Color.White;
            button2.Location = new Point(-3, 87);
            button2.Name = "button2";
            button2.Size = new Size(216, 41);
            button2.TabIndex = 2;
            button2.Text = "Home";
            button2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            panel2.Controls.Add(button1);
            panel2.Location = new Point(3, 134);
            panel2.Name = "panel2";
            panel2.Size = new Size(208, 41);
            panel2.TabIndex = 1;
            // 
            // button1
            // 
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Segoe UI", 12F);
            button1.ForeColor = Color.White;
            button1.Location = new Point(-3, 3);
            button1.Name = "button1";
            button1.Size = new Size(216, 41);
            button1.TabIndex = 2;
            button1.Text = "Manage Faculty";
            button1.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Segoe UI", 12F);
            button3.ForeColor = Color.White;
            button3.Location = new Point(3, 181);
            button3.Name = "button3";
            button3.Size = new Size(216, 44);
            button3.TabIndex = 2;
            button3.Text = "WorkLoad Requests";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Segoe UI", 12F);
            button4.ForeColor = Color.White;
            button4.Location = new Point(3, 231);
            button4.Name = "button4";
            button4.Size = new Size(216, 41);
            button4.TabIndex = 2;
            button4.Text = "Resource Requests";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Segoe UI", 12F);
            button5.ForeColor = Color.White;
            button5.Location = new Point(3, 278);
            button5.Name = "button5";
            button5.Size = new Size(216, 41);
            button5.TabIndex = 2;
            button5.Text = "Reports";
            button5.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            panel3.Location = new Point(3, 325);
            panel3.Name = "panel3";
            panel3.Size = new Size(203, 71);
            panel3.TabIndex = 1;
            // 
            // button6
            // 
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Segoe UI", 12F);
            button6.ForeColor = Color.White;
            button6.Location = new Point(3, 402);
            button6.Name = "button6";
            button6.Size = new Size(203, 48);
            button6.TabIndex = 2;
            button6.Text = "Logout";
            button6.UseVisualStyleBackColor = true;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(button9);
            Controls.Add(button7);
            Controls.Add(textBox4);
            Controls.Add(label5);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label3);
            Controls.Add(textBox1);
            Controls.Add(label6);
            Controls.Add(label1);
            Controls.Add(flowLayoutPanel1);
            Name = "Form5";
            Text = "Form5";
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            flowLayoutPanel1.ResumeLayout(false);
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private TableLayoutPanel tableLayoutPanel1;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Button button9;
        private Button button7;
        private TextBox textBox4;
        private Label label5;
        private TextBox textBox3;
        private Label label4;
        private TextBox textBox2;
        private Label label3;
        private TextBox textBox1;
        private Label label6;
        private Label label1;
        private FlowLayoutPanel flowLayoutPanel1;
        private Panel panel1;
        private Button button2;
        private Panel panel2;
        private Button button1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Panel panel3;
        private Button button6;
    }
}